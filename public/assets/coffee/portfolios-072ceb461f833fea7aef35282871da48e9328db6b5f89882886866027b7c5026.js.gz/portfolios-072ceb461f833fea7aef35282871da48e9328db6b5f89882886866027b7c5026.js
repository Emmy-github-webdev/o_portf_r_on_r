(function() {
  var ready;

  ready = void 0;

  ready = function() {
    $('.sortable').sortable();
  };

  $(document).ready(ready);

}).call(this);
